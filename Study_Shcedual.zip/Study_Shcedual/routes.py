from flask import render_template, request, redirect, url_for, flash, jsonify
from datetime import datetime, timedelta
import json
import logging

from app import app, db
from models import Subject, Chapter, StudySession, StudyPlan, ScheduleAdaptation
from ai_agent import AIStudyAgent
from scheduler import ScheduleManager
from wikipedia_service import wikipedia_service

logger = logging.getLogger(__name__)

# Initialize services
ai_agent = AIStudyAgent()
schedule_manager = ScheduleManager()

@app.route('/')
def dashboard():
    """Main dashboard showing current progress and upcoming sessions"""
    try:
        # Get progress data
        progress = schedule_manager.get_study_progress()
        
        # Get upcoming sessions
        upcoming_sessions = schedule_manager.get_current_schedule(days_ahead=7)
        
        # Get recent adaptations
        recent_adaptations = schedule_manager.get_adaptations_history(limit=5)
        
        # Get subjects for overview
        subjects = Subject.query.all()
        
        return render_template('dashboard.html', 
                             progress=progress,
                             upcoming_sessions=upcoming_sessions,
                             recent_adaptations=recent_adaptations,
                             subjects=subjects)
                             
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        flash('Error loading dashboard. Please try again.', 'error')
        return render_template('dashboard.html', 
                             progress={}, 
                             upcoming_sessions=[],
                             recent_adaptations=[],
                             subjects=[])

@app.route('/add-subjects', methods=['GET', 'POST'])
def add_subjects():
    """Add subjects for exam preparation"""
    if request.method == 'POST':
        try:
            # Get form data
            subjects_data = []
            subject_count = int(request.form.get('subject_count', 1))
            
            for i in range(subject_count):
                name = request.form.get(f'subject_name_{i}')
                chapters = int(request.form.get(f'subject_chapters_{i}', 1))
                difficulty = request.form.get(f'subject_difficulty_{i}', 'medium')
                exam_date_str = request.form.get(f'exam_date_{i}')
                
                if name and exam_date_str:
                    exam_date = datetime.strptime(exam_date_str, '%Y-%m-%d')
                    subjects_data.append({
                        'name': name,
                        'total_chapters': chapters,
                        'difficulty': difficulty,
                        'exam_date': exam_date_str
                    })
            
            if not subjects_data:
                flash('Please add at least one subject.', 'error')
                return render_template('add_subjects.html')
            
            # Use AI to break down subjects into chapters
            flash('Analyzing subjects and creating study breakdown...', 'info')
            breakdown = ai_agent.break_down_subjects(subjects_data)
            
            # Save subjects and chapters to database
            for i, subject_data in enumerate(subjects_data):
                # Create subject
                subject = Subject(
                    name=subject_data['name'],
                    total_chapters=subject_data['total_chapters'],
                    difficulty_level=subject_data['difficulty'],
                    exam_date=datetime.strptime(subject_data['exam_date'], '%Y-%m-%d')
                )
                db.session.add(subject)
                db.session.flush()  # Get the ID
                
                # Get AI breakdown for this subject
                ai_subject = None
                for breakdown_subject in breakdown.get('breakdown', []):
                    if breakdown_subject['subject_name'].lower() == subject_data['name'].lower():
                        ai_subject = breakdown_subject
                        break
                
                # Create chapters
                if ai_subject:
                    for chapter_data in ai_subject.get('chapters', []):
                        chapter = Chapter(
                            subject_id=subject.id,
                            title=chapter_data['title'],
                            estimated_hours=chapter_data.get('estimated_hours', 2.0),
                            difficulty=chapter_data.get('difficulty', 'medium')
                        )
                        db.session.add(chapter)
                else:
                    # Fallback: create generic chapters
                    for j in range(subject_data['total_chapters']):
                        chapter = Chapter(
                            subject_id=subject.id,
                            title=f"Chapter {j+1}",
                            estimated_hours=2.0,
                            difficulty=subject_data['difficulty']
                        )
                        db.session.add(chapter)
            
            db.session.commit()
            flash('Subjects added successfully! Now create a study plan.', 'success')
            return redirect(url_for('create_schedule'))
            
        except Exception as e:
            logger.error(f"Error adding subjects: {e}")
            db.session.rollback()
            flash('Error processing subjects. Please try again.', 'error')
    
    return render_template('add_subjects.html')

@app.route('/create-schedule', methods=['GET', 'POST'])
def create_schedule():
    """Create an AI-powered study schedule"""
    if request.method == 'POST':
        try:
            # Get form data
            plan_name = request.form.get('plan_name', 'Study Plan')
            start_date_str = request.form.get('start_date')
            end_date_str = request.form.get('end_date') 
            daily_hours = float(request.form.get('daily_hours', 6.0))
            
            preferred_times = []
            for i in range(3):  # Up to 3 time slots
                time_slot = request.form.get(f'time_slot_{i}')
                if time_slot:
                    preferred_times.append(time_slot)
            
            if not start_date_str or not end_date_str:
                flash('Please provide start and end dates.', 'error')
                return render_template('schedule.html')
            
            # Create study plan record
            study_plan = StudyPlan(
                name=plan_name,
                start_date=datetime.strptime(start_date_str, '%Y-%m-%d'),
                end_date=datetime.strptime(end_date_str, '%Y-%m-%d'),
                total_study_hours_per_day=daily_hours
            )
            study_plan.set_preferred_times(preferred_times)
            db.session.add(study_plan)
            db.session.commit()
            
            # Get all chapters for scheduling
            chapters = Chapter.query.all()
            if not chapters:
                flash('No subjects found. Please add subjects first.', 'error')
                return redirect(url_for('add_subjects'))
            
            # Prepare chapter data for AI
            chapters_data = []
            for chapter in chapters:
                chapters_data.append({
                    'title': chapter.title,
                    'subject_name': chapter.subject.name,
                    'estimated_hours': chapter.estimated_hours,
                    'difficulty': chapter.difficulty
                })
            
            # Prepare plan configuration
            plan_config = {
                'start_date': start_date_str,
                'end_date': end_date_str,
                'daily_hours': daily_hours,
                'preferred_times': preferred_times
            }
            
            # Generate AI schedule
            flash('Creating intelligent study schedule...', 'info')
            ai_schedule = ai_agent.create_study_schedule(chapters_data, plan_config)
            
            # Convert AI schedule to database sessions
            sessions = schedule_manager.create_sessions_from_ai_schedule(ai_schedule, study_plan.id)
            
            flash(f'Study schedule created successfully! {len(sessions)} study sessions planned.', 'success')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            logger.error(f"Error creating schedule: {e}")
            db.session.rollback()
            flash('Error creating schedule. Please try again.', 'error')
    
    # Get subjects for the form
    subjects = Subject.query.all()
    return render_template('schedule.html', subjects=subjects)

@app.route('/schedule-view')
def schedule_view():
    """View the current study schedule"""
    try:
        # Get schedule for next 14 days
        upcoming_sessions = schedule_manager.get_current_schedule(days_ahead=14)
        
        # Group sessions by date
        schedule_by_date = {}
        for session in upcoming_sessions:
            date = session['scheduled_date']
            if date not in schedule_by_date:
                schedule_by_date[date] = []
            schedule_by_date[date].append(session)
        
        return render_template('schedule.html', 
                             schedule_by_date=schedule_by_date,
                             view_mode=True)
    except Exception as e:
        logger.error(f"Error viewing schedule: {e}")
        flash('Error loading schedule.', 'error')
        return render_template('schedule.html', schedule_by_date={}, view_mode=True)

@app.route('/complete-session/<int:session_id>', methods=['POST'])
def complete_session(session_id):
    """Mark a study session as completed"""
    try:
        notes = request.form.get('notes', '')
        success = schedule_manager.mark_session_completed(session_id, notes)
        
        if success:
            flash('Session marked as completed!', 'success')
        else:
            flash('Error completing session.', 'error')
            
    except Exception as e:
        logger.error(f"Error completing session: {e}")
        flash('Error completing session.', 'error')
    
    return redirect(url_for('dashboard'))

@app.route('/miss-session/<int:session_id>', methods=['POST'])
def miss_session(session_id):
    """Mark a session as missed and trigger AI rescheduling"""
    try:
        reason = request.form.get('reason', 'Not specified')
        
        # Mark as missed
        success = schedule_manager.mark_session_missed(session_id, reason)
        
        if success:
            # Get session data for AI adaptation
            session = StudySession.query.get(session_id)
            missed_session_data = {
                'chapter_title': session.chapter.title,
                'scheduled_date': session.scheduled_date.strftime('%Y-%m-%d'),
                'start_time': session.scheduled_date.strftime('%H:%M'),
                'duration_hours': session.duration_hours,
                'miss_reason': reason
            }
            
            # Get upcoming sessions for context
            upcoming_sessions = schedule_manager.get_current_schedule(days_ahead=14)
            
            # Get current progress
            progress = schedule_manager.get_study_progress()
            
            # Get AI adaptation plan
            flash('AI is creating a smart reschedule plan...', 'info')
            adaptation = ai_agent.adapt_schedule_for_missed_session(
                missed_session_data, upcoming_sessions, progress
            )
            
            # Apply the adaptation
            adaptation_success = schedule_manager.apply_schedule_adaptation(
                adaptation, session_id, f"missed_session: {reason}"
            )
            
            if adaptation_success:
                flash('Session rescheduled intelligently by AI!', 'success')
            else:
                flash('Session marked as missed, but automatic rescheduling failed.', 'warning')
        else:
            flash('Error marking session as missed.', 'error')
            
    except Exception as e:
        logger.error(f"Error handling missed session: {e}")
        flash('Error processing missed session.', 'error')
    
    return redirect(url_for('dashboard'))

@app.route('/fetch-content/<int:chapter_id>')
def fetch_content(chapter_id):
    """Fetch Wikipedia content for a chapter"""
    try:
        chapter = Chapter.query.get_or_404(chapter_id)
        
        # Fetch Wikipedia content
        content = wikipedia_service.fetch_topic_summary(chapter.title)
        
        if content:
            # Generate AI summary
            summary = ai_agent.generate_study_summary(chapter.title, content)
            
            # Save to database
            chapter.wikipedia_content = content
            chapter.summary = summary
            db.session.commit()
            
            flash(f'Study content fetched for {chapter.title}!', 'success')
        else:
            flash(f'No Wikipedia content found for {chapter.title}.', 'warning')
            
    except Exception as e:
        logger.error(f"Error fetching content: {e}")
        flash('Error fetching study content.', 'error')
    
    return redirect(url_for('progress'))

@app.route('/progress')
def progress():
    """View detailed progress and chapter content"""
    try:
        # Get all subjects with chapters
        subjects = Subject.query.all()
        progress_data = schedule_manager.get_study_progress()
        
        # Get chapters with content
        chapters_with_content = []
        for subject in subjects:
            for chapter in subject.chapters:
                chapter_data = {
                    'id': chapter.id,
                    'title': chapter.title,
                    'subject_name': subject.name,
                    'is_completed': chapter.is_completed,
                    'difficulty': chapter.difficulty,
                    'estimated_hours': chapter.estimated_hours,
                    'has_summary': bool(chapter.summary),
                    'has_wikipedia_content': bool(chapter.wikipedia_content),
                    'summary': chapter.summary,
                    'wikipedia_content': chapter.wikipedia_content[:500] + '...' if chapter.wikipedia_content and len(chapter.wikipedia_content) > 500 else chapter.wikipedia_content
                }
                chapters_with_content.append(chapter_data)
        
        return render_template('progress.html', 
                             chapters=chapters_with_content,
                             progress=progress_data,
                             subjects=subjects)
                             
    except Exception as e:
        logger.error(f"Error loading progress: {e}")
        flash('Error loading progress data.', 'error')
        return render_template('progress.html', chapters=[], progress={}, subjects=[])

@app.route('/api/progress-chart')
def progress_chart_data():
    """API endpoint for progress chart data"""
    try:
        progress = schedule_manager.get_study_progress()
        
        # Get completion data by subject
        subjects = Subject.query.all()
        subject_progress = []
        
        for subject in subjects:
            total_chapters = len(subject.chapters)
            completed_chapters = sum(1 for ch in subject.chapters if ch.is_completed)
            completion_rate = (completed_chapters / total_chapters * 100) if total_chapters > 0 else 0
            
            subject_progress.append({
                'name': subject.name,
                'total': total_chapters,
                'completed': completed_chapters,
                'rate': round(completion_rate, 1)
            })
        
        # Get daily progress for the last 14 days
        daily_progress = []
        for i in range(14, 0, -1):
            date = datetime.now() - timedelta(days=i)
            sessions_count = StudySession.query.filter(
                db.func.date(StudySession.actual_end_time) == date.date(),
                StudySession.status == 'completed'
            ).count()
            
            daily_progress.append({
                'date': date.strftime('%m/%d'),
                'sessions': sessions_count
            })
        
        return jsonify({
            'overall': progress,
            'by_subject': subject_progress,
            'daily': daily_progress
        })
        
    except Exception as e:
        logger.error(f"Error generating chart data: {e}")
        return jsonify({'error': 'Failed to load chart data'}), 500

@app.route('/reset-schedule', methods=['POST'])
def reset_schedule():
    """Reset the entire study schedule (for testing/demo purposes)"""
    try:
        # Delete all records (cascade will handle related records)
        StudySession.query.delete()
        Chapter.query.delete()
        Subject.query.delete()
        StudyPlan.query.delete()
        ScheduleAdaptation.query.delete()
        
        db.session.commit()
        flash('Schedule reset successfully. You can now start fresh.', 'success')
        
    except Exception as e:
        logger.error(f"Error resetting schedule: {e}")
        db.session.rollback()
        flash('Error resetting schedule.', 'error')
    
    return redirect(url_for('dashboard'))

@app.errorhandler(404)
def not_found(error):
    return render_template('layout.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('layout.html'), 500
